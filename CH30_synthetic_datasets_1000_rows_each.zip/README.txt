CH30 - Campus Facility Insight (Synthetic Dataset Pack)

Each CSV contains exactly 1,000 data rows (header excluded).
- bookings.csv: facility, date, start, end, purpose
- facilities.csv: facility, type, capacity, block
- occupancy.csv: timestamp, facility, count
- calendar.csv: date, working day, event, exam period
- maintenance.csv: facility, issue, downtime

All records are synthetic and are not real campus records. Selected quality issues are intentionally included for practice: duplicate bookings, inconsistent facility-name formats, missing occupancy counts, occupancy above registered capacity, and incomplete maintenance fields.
